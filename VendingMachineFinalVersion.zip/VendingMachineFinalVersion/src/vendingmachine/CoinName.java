package vendingmachine;

public enum CoinName {
	Nickel,
	Dime,
	Quarter,
	Dollar,
	
}
